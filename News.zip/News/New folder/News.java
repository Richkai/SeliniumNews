/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rahel12
 */

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class News {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver","chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        driver.navigate().to("https://www.bbc.com");
        WebElement title = driver.findElement(By.xpath("//*[@id="page"]/section[3]/div/div/section[1]/div/ul/li[1]/div/div[2]/h3"));
        WebElement body = driver.findElement(By.xpath("//*[@id="page"]/section[3]/div/div/section[1]/div/ul/li[1]/div/div[2]/p"));
        title.getText();
        System.out.println(title.getText());
        System.out.println(body.getText());


        WebDriver newsdriver = new ChromeDriver();
        newsdriver.navigate().to("http://localhost:8000/indexclass.html");
        newsdriver.findElement(By.id("newtitle")).sendKeys(title.getText());
        newsdriver.findElement(By.id("search-input")).sendKeys(body.getText());
        newsdriver.findElement(By.name("AddNews")).click();

        driver.navigate().to("http://www.euronews.com/");
        WebElement title2 = driver.findElement(By.xpath("//*[@id="enw-main-content"]/section[2]/header/h3"));
        WebElement body2 = driver.findElement(By.xpath("//*[@id="enw-main-content"]/section[2]/div[2]"));
        System.out.println(title2.getText());
        System.out.println(body2.getText());
        newsdriver.navigate().refresh();
        newsdriver.findElement(By.id("newtitle")).sendKeys(title2.getText());
        newsdriver.findElement(By.id("search-input")).sendKeys(body2.getText());
        newsdriver.findElement(By.name("AddNews")).click();


        try {
            Thread.sleep(1000);
        }catch (Exception E){

        }
        driver.close();
        newsdriver.close();
    }
}
